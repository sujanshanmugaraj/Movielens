Developed a full-stack PERN movie review app with PostgreSQL, Express.js, React, and
Node.js. Built the frontend using Vite, React and Tailwind CSS and the backend with
Express.js. Integrated web scraping with Cheerio.js for automated data extraction.
Designed RESTful APIs for user authentication and database management.
